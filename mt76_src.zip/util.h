/*
 * Copyright (C) 2016 Felix Fietkau <nbd@nbd.name>
 * Copyright (C) 2004 - 2009 Ivo van Doorn <IvDoorn@gmail.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2
 * as published by the Free Software Foundation
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#ifndef __MT76_UTIL_H
#define __MT76_UTIL_H

#include <linux/skbuff.h>
#include <linux/bitops.h>
#include <linux/bitfield.h>

#define MT76_INCR(_var, _size) \
	_var = (((_var) + 1) % _size)

int mt76_wcid_alloc(unsigned long *mask, int size);

static inline void
mt76_wcid_free(unsigned long *mask, int idx)
{
	mask[idx / BITS_PER_LONG] &= ~BIT(idx % BITS_PER_LONG);
}

static inline void
mt76_skb_set_moredata(struct sk_buff *skb, bool enable)
{
	struct ieee80211_hdr *hdr = (struct ieee80211_hdr *) skb->data;

	if (enable)
		hdr->frame_control |= cpu_to_le16(IEEE80211_FCTL_MOREDATA);
	else
		hdr->frame_control &= ~cpu_to_le16(IEEE80211_FCTL_MOREDATA);
}

#include <linux/scatterlist.h>
static inline void sg_init_marker(struct scatterlist *sgl, unsigned int nents)
{
	if (nents)
		sg_mark_end(&sgl[nents - 1]);
}

static inline int skb_to_sgvec_nomark(struct sk_buff *skb, struct scatterlist *sg, int offset, int len)
{
	return skb_to_sgvec(skb, sg, offset, len);
}

#endif

